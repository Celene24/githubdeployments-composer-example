import React, { useState } from 'react';
import { Menu, X, Send, Palette, Megaphone, Camera, Video, PenTool, Globe, ChevronRight } from 'lucide-react';

function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('home');

  const services = [
    { icon: <Palette size={32} />, title: 'Diseño Gráfico', description: 'Identidad visual, branding y materiales promocionales' },
    { icon: <Megaphone size={32} />, title: 'Marketing Digital', description: 'Estrategias en redes sociales y campañas digitales' },
    { icon: <Camera size={32} />, title: 'Fotografía', description: 'Sesiones profesionales para productos y eventos' },
    { icon: <Video size={32} />, title: 'Producción Audiovisual', description: 'Videos corporativos y contenido para redes' },
    { icon: <PenTool size={32} />, title: 'Diseño Web', description: 'Sitios web responsivos y landing pages' },
    { icon: <Globe size={32} />, title: 'Consultoría', description: 'Asesoría en estrategias de comunicación' },
  ];

  const portfolio = [
    {
      title: 'Campaña Verano 2024',
      image: 'https://images.unsplash.com/photo-1542744173-8e7e53415bb0?auto=format&fit=crop&w=800',
      category: 'Marketing Digital'
    },
    {
      title: 'Branding Corporativo',
      image: 'https://images.unsplash.com/photo-1561070791-2526d30994b5?auto=format&fit=crop&w=800',
      category: 'Diseño Gráfico'
    },
    {
      title: 'Producción Comercial',
      image: 'https://images.unsplash.com/photo-1492724441997-5dc865305da7?auto=format&fit=crop&w=800',
      category: 'Video'
    },
    {
      title: 'Fotografía Producto',
      image: 'https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?auto=format&fit=crop&w=800',
      category: 'Fotografía'
    },
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="fixed w-full bg-white shadow-md z-50">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <Palette className="h-8 w-8 text-purple-600" />
              <span className="ml-2 text-xl font-bold text-gray-800">MATATENA</span>
            </div>
            
            {/* Desktop Menu */}
            <div className="hidden md:flex space-x-8">
              <a href="#home" onClick={() => setActiveSection('home')} 
                 className={`${activeSection === 'home' ? 'text-purple-600' : 'text-gray-600'} hover:text-purple-600 transition-colors`}>
                Inicio
              </a>
              <a href="#services" onClick={() => setActiveSection('services')}
                 className={`${activeSection === 'services' ? 'text-purple-600' : 'text-gray-600'} hover:text-purple-600 transition-colors`}>
                Servicios
              </a>
              <a href="#portfolio" onClick={() => setActiveSection('portfolio')}
                 className={`${activeSection === 'portfolio' ? 'text-purple-600' : 'text-gray-600'} hover:text-purple-600 transition-colors`}>
                Portafolio
              </a>
              <a href="#contact" onClick={() => setActiveSection('contact')}
                 className={`${activeSection === 'contact' ? 'text-purple-600' : 'text-gray-600'} hover:text-purple-600 transition-colors`}>
                Contacto
              </a>
            </div>

            {/* Mobile Menu Button */}
            <button className="md:hidden" onClick={() => setIsMenuOpen(!isMenuOpen)}>
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden bg-white border-t">
            <div className="container mx-auto px-6 py-4">
              <div className="flex flex-col space-y-4">
                <a href="#home" onClick={() => { setActiveSection('home'); setIsMenuOpen(false); }}
                   className="text-gray-600 hover:text-purple-600">Inicio</a>
                <a href="#services" onClick={() => { setActiveSection('services'); setIsMenuOpen(false); }}
                   className="text-gray-600 hover:text-purple-600">Servicios</a>
                <a href="#portfolio" onClick={() => { setActiveSection('portfolio'); setIsMenuOpen(false); }}
                   className="text-gray-600 hover:text-purple-600">Portafolio</a>
                <a href="#contact" onClick={() => { setActiveSection('contact'); setIsMenuOpen(false); }}
                   className="text-gray-600 hover:text-purple-600">Contacto</a>
              </div>
            </div>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section id="home" className="pt-20 pb-32 bg-gradient-to-br from-purple-50 to-pink-50">
        <div className="container mx-auto px-6 pt-32">
          <div className="flex flex-col md:flex-row items-center">
            <div className="md:w-1/2">
              <h1 className="text-5xl md:text-6xl font-bold text-gray-900 mb-6">
                Asertividad Creativa para tu Marca
              </h1>
              <p className="text-xl text-gray-600 mb-8">
                Transformamos ideas en experiencias memorables. Somos MATATENA, tu aliado en comunicación y creatividad.
              </p>
              <a href="#contact" 
                 className="inline-flex items-center px-8 py-4 bg-purple-600 text-white rounded-full hover:bg-purple-700 transition-colors">
                Comencemos <ChevronRight className="ml-2" />
              </a>
            </div>
            <div className="md:w-1/2 mt-12 md:mt-0">
              <img src="https://images.unsplash.com/photo-1552664730-d307ca884978?auto=format&fit=crop&w=800" 
                   alt="Creative Team" 
                   className="rounded-lg shadow-2xl" />
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-20 bg-white">
        <div className="container mx-auto px-6">
          <h2 className="text-4xl font-bold text-center text-gray-900 mb-16">Nuestros Servicios</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <div key={index} className="p-8 bg-white rounded-lg shadow-lg hover:shadow-xl transition-shadow">
                <div className="text-purple-600 mb-4">{service.icon}</div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">{service.title}</h3>
                <p className="text-gray-600">{service.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Portfolio Section */}
      <section id="portfolio" className="py-20 bg-gray-50">
        <div className="container mx-auto px-6">
          <h2 className="text-4xl font-bold text-center text-gray-900 mb-16">Portafolio</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {portfolio.map((item, index) => (
              <div key={index} className="group relative overflow-hidden rounded-lg shadow-lg">
                <img src={item.image} alt={item.title} className="w-full h-64 object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end p-6 opacity-0 group-hover:opacity-100 transition-opacity">
                  <div>
                    <h3 className="text-xl font-semibold text-white">{item.title}</h3>
                    <p className="text-gray-200">{item.category}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 bg-white">
        <div className="container mx-auto px-6">
          <h2 className="text-4xl font-bold text-center text-gray-900 mb-16">Contáctanos</h2>
          <div className="max-w-2xl mx-auto">
            <form className="space-y-6">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-gray-700">Nombre</label>
                <input type="text" id="name" className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500" />
              </div>
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700">Email</label>
                <input type="email" id="email" className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500" />
              </div>
              <div>
                <label htmlFor="message" className="block text-sm font-medium text-gray-700">Mensaje</label>
                <textarea id="message" rows={4} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500"></textarea>
              </div>
              <button type="submit" className="inline-flex items-center px-6 py-3 bg-purple-600 text-white rounded-md hover:bg-purple-700 transition-colors">
                Enviar Mensaje <Send className="ml-2 h-4 w-4" />
              </button>
            </form>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="container mx-auto px-6">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center mb-6 md:mb-0">
              <Palette className="h-8 w-8 text-purple-400" />
              <span className="ml-2 text-xl font-bold">MATATENA</span>
            </div>
            <div className="text-center md:text-right">
              <p className="text-gray-400">© 2024 MATATENA Asertividad Creativa.</p>
              <p className="text-gray-400">Todos los derechos reservados.</p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;